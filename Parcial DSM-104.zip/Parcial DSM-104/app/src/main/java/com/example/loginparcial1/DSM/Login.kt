package com.example.loginparcial1.DSM

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import com.example.loginparcial1.LoginActivity

class Login {
    lateinit var preferencia: SharedPreferences
    lateinit var editor: SharedPreferences.Editor
    lateinit var con: Context
    var PrivateMode : Int = 0

    constructor(con: Context){
        this.con = con
        preferencia = con.getSharedPreferences(PREF_NAME, PrivateMode)
        editor = preferencia.edit()
    }

    companion object{
        val PREF_NAME = "Login_preference"
        val Is_Login = "LoggedIn"
        val Key_USERNAME = "username"
        val KEY_EMAIL = "email"

    }

    fun CreateLogin(username: String, email: String){
        editor.putBoolean(Is_Login, true)
        editor.putString(Key_USERNAME, username)
        editor.putString(KEY_EMAIL, email)
        editor.commit()
    }

    fun CheckLogin(){
        if (!this.LoggedIn()){
            var i : Intent = Intent(con, LoginActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            con.startActivity(i)
        }
    }

    fun getUserDetails(): HashMap<String, String>{
        var user: Map<String, String> = HashMap<String, String>()
        (user as HashMap).put(Key_USERNAME, preferencia.getString(Key_USERNAME, null)!!)
        (user as HashMap).put(KEY_EMAIL, preferencia.getString(KEY_EMAIL, null)!!)
        return user
    }

    fun LogoutUser(){
        editor.clear()
        editor.commit()
        var i : Intent = Intent(con, LoginActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        con.startActivity(i)
    }

    fun LoggedIn():Boolean{
        return preferencia.getBoolean(Is_Login,false)
    }
}