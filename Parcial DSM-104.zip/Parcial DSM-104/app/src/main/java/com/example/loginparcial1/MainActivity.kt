package com.example.loginparcial1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import com.example.loginparcial1.DSM.Login

class MainActivity : AppCompatActivity() {

    private lateinit var txtUser : TextView
    private lateinit var txtEmail : TextView
    private lateinit var btnLogout: Button

    lateinit var  Parcial : Login

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Parcial = Login(this)

        txtUser = findViewById(R.id.txtViewUser)
        txtEmail = findViewById(R.id.txtViewEmail)
        btnLogout = findViewById(R.id.btnLog)

        Parcial.CheckLogin()

        var user: HashMap<String, String> = Parcial.getUserDetails()

        var username = user.get(Login.Key_USERNAME)
        var email = user.get(Login.KEY_EMAIL)

        txtUser.setText(username)
        txtEmail.setText(email)

        btnLogout.setOnClickListener{
            Parcial.LogoutUser()
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_login,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId){
            R.id.Ejercicio1->{
                // Acción cuando se selecciona la opción de menú 1
                val intent: Intent = Intent(this,Ejercicio01::class.java)
                startActivity(intent)
                return true
            }
            R.id.Ejercicio2->{
                // Acción cuando se selecciona la opción de menú 2
                val intent:Intent= Intent(this,Ejercicio2::class.java)
                startActivity(intent)
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }
}