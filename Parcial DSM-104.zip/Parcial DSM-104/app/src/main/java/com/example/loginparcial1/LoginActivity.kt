package com.example.loginparcial1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.loginparcial1.DSM.Login

class LoginActivity : AppCompatActivity() {

    private lateinit var txtUsername: EditText
    private lateinit var txtEmail: EditText
    private lateinit var btnLogin: Button

    lateinit var Parcial: Login



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        Parcial = Login(this)

        if(Parcial.LoggedIn()){
            var i : Intent = Intent(applicationContext, MainActivity::class.java)
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            finish()
        }

        txtUsername = findViewById(R.id.txtUser)
        txtEmail = findViewById(R.id.txtEmail)
        btnLogin = findViewById(R.id.button)

        btnLogin.setOnClickListener{
            var username = txtUsername.text.toString().trim()
            var email = txtEmail.text.toString().trim()

            if (username.isEmpty() && email.isEmpty()){
                Toast.makeText(this,"Digite el nombre de usuario y correo electronico", Toast.LENGTH_SHORT).show()


            } else{

                Parcial.CreateLogin(username, email)
                var i : Intent = Intent(applicationContext, MainActivity::class.java)
                startActivity(i)
                finish()
            }

        }

    }
}