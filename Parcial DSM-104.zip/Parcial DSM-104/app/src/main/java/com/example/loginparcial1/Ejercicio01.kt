package com.example.loginparcial1

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class Ejercicio01 : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ejercicio01)

        val btnComision:Button=findViewById(R.id.btnComision)
        btnComision.setOnClickListener{
            realizarCalculo()
        }

    }

    @SuppressLint("SuspiciousIndentation")
    private fun realizarCalculo(){

        val txtnombre:EditText=findViewById(R.id.txtName)
        val nombre:String=txtnombre.text.toString()

        val txtcodigo:EditText=findViewById(R.id.txtNumberID)
        val Codigo:Int=txtcodigo.text.toString().toInt()

        val txtventas:EditText=findViewById(R.id.txtVentas)
        var Ventas:Double=txtventas.text.toString().toDouble()

        val txtmes:EditText=findViewById(R.id.txtMes)
        var Mes:String=txtmes.text.toString()

        val txtResultado:TextView=findViewById(R.id.txtViewComision)

        //Realizando if para verificar el % de comisión en las ventas.

        var resultado=""

        if(Ventas<500){
            resultado="las ventas $Ventas de $Mes no llegaron a la meta, por lo tanto no habrá comisión."
        } else if (Ventas >=500 && Ventas<1000){
            val comision = (Ventas)*(0.05)
            resultado="las ventas $Ventas de $Mes tendrán una comisión del 5% sobre las ventas. Su Comisión es: $comision"
        }else if(Ventas>=1000 && Ventas<2000){
            val comision = (Ventas)*(0.1)
            resultado="las ventas $Ventas de $Mes tendrán una comisión del 10% sobre las ventas. Su Comisión es: $comision"
        }else if(Ventas>=2000 && Ventas<3000){
            val comision = (Ventas)*(0.15)
            resultado="las ventas $Ventas de $Mes tendrán una comisión del 15% sobre las ventas. Su Comisión es: $comision"
        }else if(Ventas>=3000 && Ventas<4000){
            val comision = (Ventas)*(0.2)
            resultado="las ventas $Ventas de $Mes tendrán una comisión del 20% sobre las ventas.Su Comisión es: $comision "
        }else if(Ventas>=4000){
            val comision = (Ventas)*(0.3)
            resultado="las ventas $Ventas de $Mes tendrán una comisión del 30% sobre las ventas.Su Comisión es: $comision"
        }

        txtResultado.text="Hola $nombre su código de empleado es $Codigo y $resultado"


            Toast.makeText(this,resultado,Toast.LENGTH_LONG).show()

        }



    }
