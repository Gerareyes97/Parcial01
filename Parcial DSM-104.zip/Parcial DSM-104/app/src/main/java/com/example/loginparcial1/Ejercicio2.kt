package com.example.loginparcial1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlin.math.sqrt

class Ejercicio2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ejercicio2)

        val campoA:EditText = findViewById(R.id.txtA)
        val campoB:EditText = findViewById(R.id.txtB)
        val campoC:EditText = findViewById(R.id.txtC)
        val BotonCalcular: Button = findViewById(R.id.btnCalcular)
        val campoRe:TextView=findViewById(R.id.txtReCuadra)

        BotonCalcular.setOnClickListener {
            val a:Double = campoA.text.toString().toDouble()
            val b:Double = campoB.text.toString().toDouble()
            val c:Double = campoC.text.toString().toDouble()


            var resul=""

            val solucion = calcularCuadratica(a, b, c)
            if (solucion != null) {
                val (x1, x2) = solucion
                resul="Las soluciones son: $x1 y $x2"

            } else {
                resul="No tiene solución"
            }

            campoRe.text="$resul"
        }
    }

    fun calcularCuadratica(a: Double, b: Double, c: Double): Pair<Double, Double>? {
        val campoRaiz = b * b - 4 * a * c
        if (campoRaiz < 0) {
            return null // La solución no es real.
        }
        val x1 = (-b + sqrt(campoRaiz)) / (2 * a)
        val x2 = (-b - sqrt(campoRaiz)) / (2 * a)
        return Pair(x1, x2)
    }


}
